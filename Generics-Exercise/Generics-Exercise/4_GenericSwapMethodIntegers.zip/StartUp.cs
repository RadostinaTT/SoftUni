﻿

namespace Generics_Exercise
{
    using System;
    using System.Linq;

    public class StartUp
    {
        public static void Main(string[] args)
        {
            Box<int> box = new Box<int>();

            int counter = int.Parse(Console.ReadLine());
            for (int i = 0; i < counter; i++)
            {
                int input = int.Parse(Console.ReadLine());
                box.Value.Add(input);
            }

            int[] command = Console.ReadLine().Split().Select(int.Parse).ToArray();
            int firstIndex = command[0];
            int secondIndex = command[1];
            box.Swap(firstIndex, secondIndex);

            Console.WriteLine(box);


            
        }
    }
}
