﻿namespace P03_FootballBetting.Data
{
    internal static class Configuration
    {
        internal static string ConnectionString = @"Server=.;Database=FootballBettingSystem;Integrated Security=True;";
    }
}
