﻿namespace BookShop.Data
{
    internal class Configuration
    {
        internal static string ConnectionString 
            => "Server=LAPTOP-0TN9PVA8;Database=BookShop;Integrated Security=True;";
    }
}
