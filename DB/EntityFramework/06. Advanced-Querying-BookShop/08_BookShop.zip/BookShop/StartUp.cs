﻿namespace BookShop
{
    using Data;
    using Initializer;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;

    public class StartUp
    {
        public static void Main()
        {
            using var db = new BookShopContext();
            //DbInitializer.ResetDatabase(db);

            //int input = int.Parse(Console.ReadLine());
            string input = Console.ReadLine();

            string result = GetBookTitlesContaining(db, input);

            Console.WriteLine(result);


        }

        //02
        public static string GetBooksByAgeRestriction(BookShopContext context, string command)
        {
            //StringBuilder sb = new StringBuilder();

            List<string> bookTitles = context
                .Books
                .AsEnumerable()
                .Where(b => b.AgeRestriction.ToString().ToLower() == command.ToLower())
                .Select(b => b.Title)
                .OrderBy(bt => bt)
                .ToList();

            return string.Join(Environment.NewLine, bookTitles);
        }

        //03
        public static string GetGoldenBooks(BookShopContext context)
        {
            List<string> bookTitles = context.Books
                .Where(b => b.EditionType == Models.Enums.EditionType.Gold && b.Copies < 5000)
                .OrderBy(b => b.BookId)
                .Select(b => b.Title)
                .ToList();

            return String.Join(Environment.NewLine, bookTitles);
        }

        //05
        public static string GetBooksNotReleasedIn(BookShopContext context, int year)
        {
            List<string> bookTitlesNotReleased = context.Books
                .Where(b => b.ReleaseDate.Value.Year != year)
                .OrderBy(b => b.BookId)
                .Select(b => b.Title)
                .ToList();

            return String.Join(Environment.NewLine, bookTitlesNotReleased);
        }

        //06
        public static string GetBooksByCategory(BookShopContext context, string input)
        {
            string[] categories = input
                .Split(' ', StringSplitOptions.RemoveEmptyEntries)
                .Select(c => c.ToLower())
                .ToArray();

            List<string> booksByCategory = new List<string>();

            foreach (var cat in categories)
            {
                List<string> currentBooks = context.Books
                .Where(b => b.BookCategories.Any(bc => bc.Category.Name.ToLower() == cat))
                .Select(b => b.Title)
                .ToList();

                booksByCategory.AddRange(currentBooks);
            }

            booksByCategory = booksByCategory.OrderBy(bc => bc).ToList();
                       
            return String.Join(Environment.NewLine, booksByCategory);
        }

        //09
        public static string GetBookTitlesContaining(BookShopContext context, string input)
        {
            List<string> bookTitlesContaining = context.Books
                .Where(b => b.Title.ToLower().Contains(input.ToLower()))                
                .Select(b => b.Title)
                .OrderBy(b => b)
                .ToList();

            return String.Join(Environment.NewLine, bookTitlesContaining);
        }
    }
}
