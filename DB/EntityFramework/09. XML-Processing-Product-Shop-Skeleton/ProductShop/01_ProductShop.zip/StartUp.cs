﻿using ProductShop.Data;
using System.IO;
using ProductShop.XMLHelper;
using ProductShop.Dtos.Import;
using System.Linq;
using ProductShop.Models;
using System;

namespace ProductShop
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            using ProductShopContext context = new ProductShopContext();

            context.Database.EnsureDeleted();
            Console.WriteLine("Db was successfully deleted!");
            context.Database.EnsureCreated();
            Console.WriteLine("Db was successfully created!");

            string inputXml = File.ReadAllText("../../../Datasets/users.xml");

            var result = ImportUsers(context, inputXml);

            System.Console.WriteLine(result);
        }

        //01
        public static string ImportUsers(ProductShopContext context, string inputXml)
        {
            const string rootElement = "Users";
            var userResult = XmlConverter.Deserializer<ImportUserDto>(inputXml, rootElement);

            var users = userResult.Select(u => new User
            {
                FirstName = u.FirstName,
                LastName = u.LastName,
                Age = u.Age
            })
            .ToArray();

            context.Users.AddRange(users);
            context.SaveChanges();

            return $"Successfully imported {users.Length}";
        }
    }
}