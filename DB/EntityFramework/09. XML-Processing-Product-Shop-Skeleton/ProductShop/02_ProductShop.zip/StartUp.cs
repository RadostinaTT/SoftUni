﻿using ProductShop.Data;
using System.IO;
using ProductShop.XMLHelper;
using ProductShop.Dtos.Import;
using System.Linq;
using ProductShop.Models;
using System;

namespace ProductShop
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            using ProductShopContext context = new ProductShopContext();

            //context.Database.EnsureDeleted();
            //Console.WriteLine("Db was successfully deleted!");
            //context.Database.EnsureCreated();
            //Console.WriteLine("Db was successfully created!");

            string inputXml = File.ReadAllText("../../../Datasets/products.xml");

            var result = ImportProducts(context, inputXml);

            System.Console.WriteLine(result);
        }

        //01
        public static string ImportUsers(ProductShopContext context, string inputXml)
        {
            const string rootElement = "Users";
            var userResult = XmlConverter.Deserializer<ImportUserDto>(inputXml, rootElement);

            var users = userResult.Select(u => new User
            {
                FirstName = u.FirstName,
                LastName = u.LastName,
                Age = u.Age
            })
            .ToArray();

            context.Users.AddRange(users);
            context.SaveChanges();

            return $"Successfully imported {users.Length}";
        }

        //02
        public static string ImportProducts(ProductShopContext context, string inputXml)
        {
            const string rootElement = "Products";
            var userResult = XmlConverter.Deserializer<ImportProductDto>(inputXml, rootElement);

            var products = userResult.Select(u => new Product
            {
                Name = u.Name,
                Price = u.Price,
                SellerId = u.SellerId,
                BuyerId = u.BuyerId
            })
            .ToArray();

            context.Products.AddRange(products);
            context.SaveChanges();

            return $"Successfully imported {products.Length}";
        }
    }
}