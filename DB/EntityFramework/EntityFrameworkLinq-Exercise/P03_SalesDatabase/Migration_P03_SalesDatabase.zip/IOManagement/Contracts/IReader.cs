﻿namespace P03_SalesDatabase.IOManagement.Contracts
{
    public interface IReader
    {
        string ReadLine();
    }
}
