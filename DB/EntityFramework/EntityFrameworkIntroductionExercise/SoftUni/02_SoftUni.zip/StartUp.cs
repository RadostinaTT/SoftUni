﻿using System;

namespace SoftUni
{
    class StartUp
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
