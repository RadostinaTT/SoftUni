﻿namespace BorderControl
{
    public interface IInhabitant
    {
        public string Id { get; }
    }
}