﻿namespace BorderControl
{
    using System;
    using System.Collections.Generic;
    using System.Linq;

    public class Program
    {
        static void Main(string[] args)
        {
            List<IInhabitant> inhabitants = new List<IInhabitant>();

            string input = Console.ReadLine();
            while (input != "End")
            {
                string[] inputInfo = input.Split();
                if (inputInfo.Length == 2)
                {
                    string model = inputInfo[0];
                    string id = inputInfo[1];
                    Robot robot = new Robot(id, model);
                    inhabitants.Add(robot);
                }
                else
                {
                    string name = inputInfo[0];
                    int age = int.Parse(inputInfo[1]);
                    string id = inputInfo[2];
                    Citizen citizen = new Citizen(id, name, age);
                    inhabitants.Add(citizen);
                }

                input = Console.ReadLine();
            }
            string criteria = Console.ReadLine();

            foreach (var inhabitant in inhabitants.Where(x => x.Id.EndsWith(criteria)))
            {
                Console.WriteLine(inhabitant.Id);
            }
        }
    }
}