﻿namespace BorderControl
{
    public class Citizen : IInhabitant
    {
        public Citizen(string id, string name, int age)
        {
            this.Id = id;
            this.Name = name;
            this.Age = age;
        }

        public string Id { get; }
        public string Name { get; set; }
        public int Age { get; set; }
    }
}