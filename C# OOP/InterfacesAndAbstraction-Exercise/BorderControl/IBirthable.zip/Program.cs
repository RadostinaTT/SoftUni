﻿namespace BorderControl
{
    using System;
    using System.Collections.Generic;
    using System.Linq;

    public class Program
    {
        static void Main(string[] args)
        {
            List<IBirthable> collection = new List<IBirthable>();

            string input = Console.ReadLine();
            while (input != "End")
            {
                string[] inputInfo = input.Split(" ", StringSplitOptions.RemoveEmptyEntries);
                if (inputInfo[0] == "Citizen")
                {
                    string name = inputInfo[1];
                    int age = int.Parse(inputInfo[2]);
                    string id = inputInfo[3];
                    string birthday = inputInfo[4];
                    Citizen citizen = new Citizen(id, name, age, birthday);
                    collection.Add(citizen);
                }
                else if (inputInfo[0] == "Pet")
                {
                    string name = inputInfo[1];
                    string birthday = inputInfo[2];
                    Pet pet = new Pet(name, birthday);
                    collection.Add(pet);
                }

                input = Console.ReadLine();
            }
            string criteria = Console.ReadLine();

            foreach (var item in collection.Where(x => x.Birthday.EndsWith(criteria)))
            {
                Console.WriteLine(item.Birthday);
            }
        }
    }
}