﻿namespace Telephony
{
    public interface ICaller
    {
        public string Calling(string number);
    }
}