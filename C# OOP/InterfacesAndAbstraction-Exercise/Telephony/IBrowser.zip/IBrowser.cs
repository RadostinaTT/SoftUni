﻿namespace Telephony
{
    public interface IBrowser
    {
        public string Browsing(string url);
    }
}