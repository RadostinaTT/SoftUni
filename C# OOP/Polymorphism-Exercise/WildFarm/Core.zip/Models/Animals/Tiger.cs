﻿namespace WildFarm.Models.Animals
{
    using System;
    using System.Collections.Generic;
    using WildFarm.Models.Foods;
    public class Tiger : Feline
    {
        private const double TigerWeight = 1.00;
        public Tiger(string name, double weight, string livingRegion, string breed) 
            : base(name, weight, livingRegion, breed)
        {
        }

        protected override double WeightMiultiplier => TigerWeight;

        protected override ICollection<Type> AllowedFoods { get; }

        public override void ProduceSound()
        {
            System.Console.WriteLine("ROAR!!!");
        }

        public override string ToString()
        {
            return $"Tiger [{this.Name}, {this.Breed}, {this.Weight}, {this.LivingRegion}, {this.FoodEaten}]";
        }
        protected override void ValidateFood(Food food)
        {
            string type = food.GetType().Name;

            if (type != nameof(Meat))
            {
                throw new ArgumentException($"{this.GetType().Name} does not eat {food.GetType().Name}!");
            }
        }
    }
}