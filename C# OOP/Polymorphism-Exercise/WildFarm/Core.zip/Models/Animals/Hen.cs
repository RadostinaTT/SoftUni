﻿namespace WildFarm.Models.Animals
{
    using System;
    using System.Collections.Generic;
    using WildFarm.Models.Foods;

    public class Hen : Bird
    {
        private const double HenWeight = 0.35;
        public Hen(string name, double weight, double wingSize) 
            : base(name, weight, wingSize)
        {
            this.AllowedFoods = new List<Type>
            {
                typeof(Vegetable),
                typeof(Fruit),
                typeof(Meat),
                typeof(Seeds),

            };
        }

        protected override double WeightMiultiplier => HenWeight;

        protected override ICollection<Type> AllowedFoods { get; }

        public override void ProduceSound()
        {
            System.Console.WriteLine("Cluck");
        }

        public override string ToString()
        {
            return $"Hen [{this.Name}, {this.WingSize}, {this.Weight}, {this.FoodEaten}]";
        }
        protected override void ValidateFood(Food food)
        {
            string type = food.GetType().Name;

            if (type != nameof(Vegetable) && type != nameof(Meat) &&
                type != nameof(Fruit) && type != nameof(Seeds))
            {
                throw new ArgumentException($"{this.GetType().Name} does not eat {food.GetType().Name}!");
            }
        }
    }
}