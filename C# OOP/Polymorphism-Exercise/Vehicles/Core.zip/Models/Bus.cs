﻿namespace Vehicles.Models
{
    public class Bus : Vehicle
    {
        private const double AirConditionAditionConsumption = 1.4;
        public Bus(double fuelQuantity, double fuelConsumption, double tankCapacity) 
            : base(fuelQuantity, fuelConsumption, tankCapacity)
        {
        }

        public bool IsEmpty { get; set; }
        public override bool Drive(double distance)
        {
            if (!IsEmpty)
            {
                this.FuelConsumption += AirConditionAditionConsumption;
            }
            return base.Drive(distance);
        }
    }
}