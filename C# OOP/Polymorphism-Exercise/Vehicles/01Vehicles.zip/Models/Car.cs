﻿namespace Vehicles.Models
{
    public class Car : Vehicle
    {
        private const double AirConditionAditionConsumption = 0.9;

        public Car(double fuelQuantity, double fuelConsumption) 
            : base(fuelQuantity, fuelConsumption)
        {
            this.FuelConsumption += AirConditionAditionConsumption;
        }

        public override void Refuel(double fuel)
        {
            base.Refuel(fuel);
        }
    }
}