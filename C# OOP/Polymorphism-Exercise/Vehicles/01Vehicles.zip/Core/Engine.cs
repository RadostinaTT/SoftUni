﻿namespace Vehicles.Core
{
    using System;
    using System.Linq;

    using Models;

    class Engine
    {
        public void Run()
        {
            string[] carInfo = Console.ReadLine()
                .Split()
                .ToArray();

            double carFuelQuantity = double.Parse(carInfo[1]);
            double carFuelConsumption = double.Parse(carInfo[2]);

            var car = new Car(carFuelQuantity, carFuelConsumption);

            string[] truckInfo = Console.ReadLine()
                .Split()
                .ToArray();
 
            double truckFuelQuantity = double.Parse(truckInfo[1]);
            double truckFuelConsumption = double.Parse(truckInfo[2]);
            
            var truck = new Truck(truckFuelQuantity, truckFuelConsumption);

            int countCommands = int.Parse(Console.ReadLine());

            for (int i = 0; i < countCommands; i++)
            {
                string[] inputInfo = Console.ReadLine()
                    .Split()
                    .ToArray();
                string command = inputInfo[0];
                string typeVehicle = inputInfo[1];
                double value = double.Parse(inputInfo[2]);
                switch (command)
                {
                    case "Drive":
                        switch (typeVehicle)
                        {
                            case "Car":
                                DriveVehicle(car, value);
                                break;
                            case "Truck":
                                DriveVehicle(truck, value);
                                break;
                            default:
                                break;
                        }
                        break;
                    case "Refuel":
                        switch (typeVehicle)
                        {
                            case "Car":
                                car.Refuel(value);
                                break;
                            case "Truck":
                                truck.Refuel(value);
                                break;
                            default:
                                break;
                        }
                        break;
                    
                    default:
                        break;
                }
            }
            Console.WriteLine($"Car: {car.FuelQuantity:f2}");
            Console.WriteLine($"Truck: {truck.FuelQuantity:f2}");
        }

        public static void DriveVehicle(Vehicle vehicle, double value)
        {
            bool cantravell = vehicle.Drive(value);

            string result = !cantravell
                ? $"{vehicle.GetType().Name} needs refueling"
                : $"{vehicle.GetType().Name} travelled {value} km";

            Console.WriteLine(result);
        }
    }
}