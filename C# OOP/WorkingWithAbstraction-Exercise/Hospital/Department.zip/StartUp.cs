﻿using System;

namespace Hospital
{
    public class StartUp
    {
        static void Main()
        {
            Engine engine = new Engine();

            engine.Run();
        }
    }
}
