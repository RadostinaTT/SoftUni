﻿using System;
using System.Collections.Generic;

namespace RawData
{
    public class Program
    {
        public static void Main(string[] args)
        {
            int countCars = int.Parse(Console.ReadLine());
            Car[] car = new Car[countCars];
            for (int i = 0; i < countCars; i++)
            {
                var input = Console.ReadLine();
                var parts = input.Split();
                //"{model} {engineSpeed} {enginePower} {cargoWeight} {cargoType} {tire1Pressure} {tire1Age} {tire2Pressure} {tire2Age} {tire3Pressure} {tire3Age} {tire4Pressure} {tire4Age}"
                string model = parts[0];
                int engineSpeed = int.Parse(parts[1]);
                int enginePower = int.Parse(parts[2]);
                int cargoWeight = int.Parse(parts[3]);
                string cargoType = parts[4];
                double tire1Pressure = double.Parse(parts[5]);
                int tire1Age = int.Parse(parts[6]);
                double tire2Pressure = double.Parse(parts[7]);
                int tire2Age = int.Parse(parts[8]);
                double tire3Pressure = double.Parse(parts[9]);
                int tire3Age = int.Parse(parts[10]);
                double tire4Pressure = double.Parse(parts[11]);
                int tire4Age = int.Parse(parts[12]);

                car[i] = new Car( model, new Engine(engineSpeed, enginePower), new Cargo(cargoWeight, cargoType), new List<Tyre> { new Tyre(tyre1Pressure, tyre1Age), new Tyre(tyre2Pressure, tyre2Age), new Tyre(tyre3Pressure, tyre3Age), new Tyre(tyre4Pressure, tyre4Age) })
            }
        }
    }
}
